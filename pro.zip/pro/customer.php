<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Purchase</title>
    <style>
         body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #333333;
            color: #ffffff;
            background-image: url('image1.jpg'); 
            background-size: cover;
            background-position: center;
        }
        .container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            color: #333;
        }
        form {
            margin-top: 20px;
            text-align: center;
        }
        label {
            display: block;
            margin-bottom: 5px;
            color: #555;
        }
        input[type="text"],
        input[type="number"],
        select {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        input[type="date"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="container">
        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
            <h2>Add Purchase</h2>

            <label for="customerName">Customer Name:</label>
            <input type="text" id="customerName" name="customerName" required>

            <label for="productName">Product Name:</label>
            <select id="productName" name="productName">
                <?php
                // Database connection
                $servername = "localhost";
                $username = "root"; // Your MySQL username
                $password = ""; // Your MySQL password
                $dbname = "pro"; // Your MySQL database name

                // Create connection
                $conn = new mysqli($servername, $username, $password, $dbname);

                // Check connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                // Fetch product names from Products table
                $sql = "SELECT ProductName, ProductPrice FROM Products";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<option value='" . $row["ProductName"] . "'>" . $row["ProductName"] . " - $" . $row["ProductPrice"] . "</option>";
                    }
                }

                // Close connection
                $conn->close();
                ?>
            </select>

            <label for="productQuantity">Product Quantity:</label>
            <input type="number" id="productQuantity" name="productQuantity" min="1" required>

            <label for="purchaseDate">Purchase Date:</label>
            <input type="date" id="purchaseDate" name="purchaseDate" required>

            <input type="submit" name="submit" value="Add Purchase">
        </form>

        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Database connection
            $servername = "localhost";
            $username = "root"; // Your MySQL username
            $password = ""; // Your MySQL password
            $dbname = "pro"; // Your MySQL database name

            // Create connection
            $conn = new mysqli($servername, $username, $password, $dbname);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Retrieve form data
            $customerName = $_POST['customerName'];
            $productName = $_POST['productName'];
            $productQuantity = $_POST['productQuantity'];
            $purchaseDate = $_POST['purchaseDate'];

            // Fetch product price from Products table
            $sql = "SELECT ProductPrice FROM Products WHERE ProductName='$productName'";
            $result = $conn->query($sql);
            $row = $result->fetch_assoc();
            $productPrice = $row["ProductPrice"];

            // Calculate total price
            $totalPrice = $productPrice * $productQuantity;

            // Insert data into Customers table
            $sql = "INSERT INTO Customers (CustomerName, ProductName, ProductPrice, ProductQuantity, PurchaseDate, TotalPrice)
                    VALUES ('$customerName', '$productName', '$productPrice', '$productQuantity', '$purchaseDate', '$totalPrice')";

            if ($conn->query($sql) === TRUE) {
                echo "<p style='color: green;'>Purchase recorded successfully!</p>";
            } else {
                echo "<p style='color: red;'>Error: " . $sql . "<br>" . $conn->error . "</p>";
            }

            // Close connection
            $conn->close();
        }
        ?>
        <a href="home.php" class="button" style="display: inline-block; background-color: #4CAF50; color: white; text-align: center; padding: 14px 20px; text-decoration: none; margin: 10px 5px; cursor: pointer; border: none; border-radius: 4px;">Add Purchase</a>
<a href="customer.php" class="button" style="display: inline-block; background-color: #008CBA; color: white; text-align: center; padding: 14px 20px; text-decoration: none; margin: 10px 5px; cursor: pointer; border: none; border-radius: 4px;">BILLING</a>
<a href="best.php" class="button" style="display: inline-block; background-color: #f44336; color: white; text-align: center; padding: 14px 20px; text-decoration: none; margin: 10px 5px; cursor: pointer; border: none; border-radius: 4px;">BEST ONCES</a>

    </div>
</body>
</html>
